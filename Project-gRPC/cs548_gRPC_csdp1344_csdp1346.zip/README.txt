1. Mono GO kai gRPC
2. Search for TempleOS
